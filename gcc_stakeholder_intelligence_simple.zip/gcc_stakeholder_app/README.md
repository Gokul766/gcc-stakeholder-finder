# GCC Stakeholder Intelligence — Manual Search + Excel Upload

## Features
- Manual search: enter a company name and India GCC Head, then click **Find Global Stakeholders**.
- Bulk research: upload `.xlsx` or `.csv`, map columns, research up to 50 rows per run.
- Evidence-first Tavily web search + Anthropic Claude analysis.
- Editable findings, evidence URLs, uncertainty labels, Excel export.

## Install locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Google Colab
1. Upload the project ZIP in the Colab Files sidebar.
2. Run:
```python
!unzip -o /content/gcc_stakeholder_intelligence_simple.zip -d /content/gcc_simple
!pip install -r /content/gcc_simple/gcc_stakeholder_app/requirements.txt
```
3. Start Streamlit:
```python
import subprocess
p = subprocess.Popen(['streamlit','run','/content/gcc_simple/gcc_stakeholder_app/app.py','--server.port=8501','--server.address=0.0.0.0','--server.headless=true'],stdout=open('/content/gcc_simple_streamlit.log','w'),stderr=subprocess.STDOUT)
```
4. Display:
```python
from google.colab import output
output.serve_kernel_port_as_iframe(8501, height=900)
```
5. Enter your own Anthropic and Tavily API keys in the sidebar. API usage can incur charges.

**Security:** Use only approved company data. Do not share API keys or deploy an unauthenticated public instance. Public web snippets do not prove organizational reporting; manually review evidence.
